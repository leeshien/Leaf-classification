Class	 Species name
(1)  	 q_aff_cerris
(2)  	 q_rubur_f_purpubascens
(3)  	 q_x_hispanica
(4)  	 q_x_kewensis
(5)  	 q_x_ludoviciana
(6) 	 q_x_mannifera
(7)  	 q_x_rosacea
(8)  	 q_x_turneri
(9) 	 qacutissima
(10)     qagriefolia
